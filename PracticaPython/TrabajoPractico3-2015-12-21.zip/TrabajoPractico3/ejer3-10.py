#  10) Escribir un programa el cual lea dos valores enteros. Si el primero es menor que el

#  segundo, que imprima el mensaje ``Arriba''. Si el segundo es menor que el primero, que 

#  imprima el mensaje ``Abajo''. Si los números son iguales, que imprima el mensaje 

#  "igual''. Si alguno de los datos ingresados es igual a 0, que imprima un mensaje 

#  conteniendo la palabra ``Error''.

print('Presione S si desea comparar dos numeros y Presion n Para Salir ')

sigo=str(input())
while (sigo == 's'):
  
 print ("Ingrese primer  valor: ")
 num1 = int(input ())
 print ("Ingrese segundo valor: ")
 num2 = int(input ())
 
 if (num1== 0 or num2 == 0 ):
   print ('ERRROOOOORRR LOCOOOO :( ')
   print('Presione S si desea comparar dos numeros y Presion n Para Salir ')
   sigo= str(input())
 elif  (num1 < num2):
   print('ARRIBA')
   print('Presione S si desea comparar dos numeros y Presion n Para Salir ')
   sigo= str(input())
 elif(num1> num2):
   print('ABAJO')
   print('Presione S si desea comparar dos numeros y Presion n Para Salir ')
   sigo= str(input()) 
 else:	
   print('IGUAL')
   print('Presione S si desea comparar dos numeros y Presion n Para Salir ')
   sigo= str(input())




