numero=int(input('ingrese numero: '))
for divisor in range (numero -1,0,-1):
    if (numero%divisor)==0:
        print (divisor)
