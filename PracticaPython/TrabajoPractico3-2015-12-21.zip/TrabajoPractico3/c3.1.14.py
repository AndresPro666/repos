costoFijo=10
costoPP=10
costoPM=15
costoPG=20
costoP=5
costoCh=10
costoCe=15
costoTot=0
opsion=input("Desea calcular el precio de la piza? (si/no)")
while opsion!='si' and opsion!='no':
   opsion=input("Desea calcular el precio de la piza? (si/no)")
while opsion=='si'
    tamañoPiza=int(input("""ingrese tamoño piza
    0=pequeña
    1=mediana
    2=grande""")
    while not (tamañoPiza in range(0,3)):
        tamañoPiza=int(input("""ingrese tamoño piza
0=pequeña
1=mediana
2=grande""")
    while 
                
    
