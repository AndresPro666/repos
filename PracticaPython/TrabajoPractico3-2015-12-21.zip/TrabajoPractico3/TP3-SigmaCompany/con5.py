print ("Esto es el ejercicio numero cincooooooooooooo")

renzo= 2
renzo+=2 + 4
renzo= 8*9
renzo= 8/9
renzo= renzo**2

print ("Esto es el valor de renzo", renzo)
