
print("""

       PERRANDO""")
presu=int(input("ingrese el presupuesto anual "))


pedi=presu*0.6
trauma=presu*0.2
kine=presu*0.2
print("el presupuesto para pediatria es ", pedi)
print("el presupuesto para traumatologia es ", trauma)
print("el presupuesto para kinesiologia es ", kine)
     