
print("""

       SISTEMA DE ALUMNADO PROMEDIO NOTAS""")
x=int(input("ingrese la nota 1 "))
y=int(input("ingrese la nota 2 "))
z=int(input("ingrese la nota 3 "))


promedio=(x+y+z)/3
if (promedio>=7):
    print("Safaste ")
else:
    print("Burrrooooooo")
