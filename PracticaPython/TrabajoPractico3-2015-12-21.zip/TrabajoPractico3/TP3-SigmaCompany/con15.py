
print("""

        Detectar  figura""")
l1=int(input("ingrese el longitud lado 1 "))
l2=int(input("ingrese longitud lado 2 "))
l3=int(input("ingrese longitud lado 3 "))
if (l1>(l2+l3)):
      print("No se trata de un triangulo")  
if ((l1**2)==(l2**2)+(l3**2)):
	print("es un triangulo rectangulo")
if ((l1**2)>(l2**2)+(l3**2)):
	print("es un triangulo obtusángulo")  
if ((l1**2)<(l2**2)+(l3**2)):
	print("es un triangulo acutángulo")  


	

