
print("""

        Detectar si un numero dado es menor a los otros dos""")
c=int(input("ingrese el primer numero  "))
d=int(input("ingrese el segundo numero  "))
e=int(input("ingrese el tercer numero  "))
if (c<d) and (c<e):
      print(str(c)+" es menor que los otros dos")  
else:  
 print(str(c)+" no es menor que los otros dos") 
