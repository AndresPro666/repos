
print ("Esto es el ejercicio numero tres")

z= 2
z+=2
z+=2-2
z*=2
print ("Esto es el valor de z", z)

x='a'
x*=2
x+='b'
x= x * 2 + 'c' * 3
print ("Esto es el valor de x", x)