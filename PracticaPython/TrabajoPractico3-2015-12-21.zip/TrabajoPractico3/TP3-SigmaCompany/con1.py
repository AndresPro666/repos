
print ("Esto es el ejercicio numero uno")

a= (4/2)**5
b=(4+2)/(2*2)
c=2+(3*(6/2))
d="+--+-8"
print("ESTE ES A" , a)
print("ESTE ES B" , b)
print("ESTE ES C" , c)
print("ESTE ES D" , d)
