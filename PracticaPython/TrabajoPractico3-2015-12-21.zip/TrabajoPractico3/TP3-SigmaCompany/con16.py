
print("""

       SISTEMA CONTABLE DE JUGADORES""")
sueldo=int(input("ingrese el sueldo "))


if (sueldo>0) and (sueldo<6000):
      print("sueldo actual es ", sueldo)
      print("el tanto porciento del aumento es el 15% ")
      print("el sueldo aumentado es ", sueldo+ (sueldo * 0.155))
if (sueldo>=6000) and (sueldo<=7900):
      print("sueldo actual es ", sueldo)
      print("el tanto porciento del aumento es el 10% ")
      print("el sueldo aumentado es ", sueldo+(sueldo * 0.1))
if (sueldo>7900) and (sueldo<12000):
      print("sueldo actual es ", sueldo)
      print("el tanto porciento del aumento es el 6% ")
      print("el sueldo aumentado es ", sueldo+(sueldo * 0.06))
if (sueldo>12000):
      print("sueldo actual es ", sueldo)
      print("el tanto porciento del aumento es el 0% ")
      print("el sueldo aumentado es ", sueldo)
