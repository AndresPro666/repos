
print("""

       SISTEMA DE INVERSION""")
x=int(input("ingrese la inversion de A "))
y=int(input("ingrese la inversion de B "))
z=int(input("ingrese la inversion de C "))


total=x+y+z

print("A es dueño del porcentaje de la empresa ", (x*100/total))
print("B  es dueño del porcentaje de la empresa ", (y*100/total))
print("C  es dueño del porcentaje de la empresa ", (z*100/total))
     