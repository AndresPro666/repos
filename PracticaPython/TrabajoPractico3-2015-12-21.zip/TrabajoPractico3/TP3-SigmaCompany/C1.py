
def menu():
    print ("""


        -----------Menu :) -------------
    1. Ejercicio numero 1.1
    2. Ejercicio numero 1.2
    3. Ejercicio numero 1.3
    4. Ejercicio numero 1.4
    5. Ejercicio numero 1.5
    6. Ejercicio numero 1.6
    7. Ejercicio numero 1.7
    8. Ejercicio numero 1.8
    9. Ejercicio numero 1.9
    10. Ejercicio numero 1.10
    11. Ejercicio numero 1.11
    12. Ejercicio numero 1.12
    13. Ejercicio numero 1.13
    14. Ejercicio numero 1.14
    15. Ejercicio numero 1.15
    16. Ejercicio numero 1.16
    17. Ejercicio numero 1.17

    7. Salir

    """)



menu()
opcion=int(input("""
    Elige una opcion  -->"""))
if (opcion==1):
    a=input("ingrese el primer numero  ")
    b=input("ingrese el segundo numero  ")
    c=input("ingrese el segundo numero  ")
    print ("""
        Los numeros ingresados son """, a, b , c)

if(opcion==2):
    a=int(input("Ingrese un numero "))
    res= (a//2)
    print("La division entera es ", res)

if(opcion==3):
    nota1=int(input("Ingrese la primer nota "))
    nota2=int(input("ingrese la segunda nota "))
    nota3=int(input("ingrese la tercer nota "))
    promedio= ((nota1+nota2+nota3)/3)
    print("""

    El promedio del alumno es ---> """, promedio)

if (opcion==4):
    base=float(input("Ingrese la base de la figura "))
    altura=float(input("Ingrese la altura de la figura "))
    perimetro=(2*(base+altura))
    area=(base * altura)
    print("""
        El perimetro de la figura es ---> """, perimetro)
    print("""
        El area de la figura es ---> """, area)

if (opcion==5):
    medida=int(input("ingrese los metros que desea convertir "))
    res= (medida * 100)
    print(" Centimetros ---> ", res )

if (opcion==6):
    x=int(input("ingrese el valor de x "))
    y=5*x**2 + 3*x -1
    print(" El valor de y ---> ", y )

if (opcion==7):
    print("""

        BIENVENIDO AL SISTEMA DE LIQUIDACION DE SUELDOS JAJA """)
    name=input("Ingrese el Nombre del Empleado ")
    nauto=int(input("Cuantos autos vendio? --->"))
    efete=float(input("ingrese el EFETE TOTAL --->"))
    comision= (1200 * nauto)
    incremento=((5*efete)/100)
    salario=4600+incremento+comision
    print("el salario es de ---> ", salario)

if (opcion==8):
   cad1=input("Ingresa el Nombre de tu vieja ---->")
   cad2=input("Ingresa el apellido de tu vieja ---->")
   lista=[cad1,cad2]
   lista.reverse()
   print (lista)

if (opcion==9):
    dollars=float(input("ingrese el valor de cotizacion "))
    pesos=float(input("ingrese la cantidad en pesos "))
    print("el valor en dolares es --->", pesos/dollars)

if (opcion==10):
    p1=float(input("ingrese costo producto 1 "))
    p2=float(input("ingrese costo producto 2 "))
    p3=float(input("ingrese costo producto 3 "))
    tot=p1+p2+p3
    print("Usted debe pagar --->", tot*1.21)

if(opcion==11):
    nota1=int(input("Ingrese la primer nota "))
    nota2=int(input("ingrese la segunda nota "))
    nota3=int(input("ingrese la tercer nota "))
    promedio= ((nota1+nota2+nota3)/3)
    print("""

    El promedio del alumno es ---> """, promedio)

if (opcion==12):
    base=float(input("Ingrese la base de la figura "))
    altura=float(input("Ingrese la altura de la figura "))
    area=(base * altura)
   
    print("""
        La superficie de la figura es ---> """, area)
if (opcion==13):
    n1=float(input("Ingrese primer valor "))
    n2=float(input("Ingrese segundo valor "))
    n3=float(input("Ingrese tercer valor "))
    
   
    print("""
        La media geometrica es ---> """, ((n1*n2*n3)/3))


if (opcion==14):
    n1=float(input("Ingrese primer valor "))
    n2=float(input("Ingrese segundo valor "))
    n3=float(input("Ingrese tercer valor "))
    
   
    print("""
        La media geometrica es ---> """, ((n1*n2*n3)/3))

if (opcion==15):
    print("""

        BIENVENIDO AL SISTEMA CONSTRUCTORA SRL JAJA """)
    
    nH=int(input("Cuantos horas trabajo Juan Perez? --->"))
    salario=77*nH
    print("el salario semanal de Juan Perez es ---> ", salario)

if (opcion==16):
    print("""

        BIENVENIDO AL SISTEMA DE ALUMNADO """)
    
    dclases=float(input("Cantidad de dias de clases --->"))
    dausentes=float(input("Cantidad de dias ausentes --->"))
    dasistidos=dclases - dausentes   
    asistencia=100*(dasistidos/dclases)
  
    print("porcentaje de asistencia es ---> ", asistencia)

if (opcion==17):
    n1=float(input("Ingrese primer valor "))
    n2=float(input("Ingrese segundo valor "))
    n3=float(input("Ingrese tercer valor "))
    n1t=n1*3
    n2t=n2*3
    n3t=n3*3
   
    print("""
        Los triplos respectivamente son ---> """, n1t,n2t, n3t)