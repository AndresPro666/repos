
print("""

       SUPERMERK2""")
cod=str(input("ingrese el CODIGO DE BARRAS "))
print("FERNET --------> 01")
print("CERVEZA --------> 02")
fernet=80
cerveza=20

if (cod == "01"):
      print("ha obtenido un descuento ")
      print("el descuento es el del 10% ")
      print("el precio del fernet es de ", fernet)
      print("el subtotal final es de ", fernet - (fernet * 0.10))
if (cod=="02"):
        print("ha obtenido un descuento ")
        print("el descuento es el del 15% ")
        print("el precio de la bajo cero es de ", cerveza)
        print("el subtotal final es de ", cerveza - (cerveza * 0.10))

