

print ("Esto es el ejercicio numero cuatro")
print(True== True != False)
print(1<2<3<4<5)
print((1<2<10) and (5>3))
print(((2>1>0) and (3<2<4)) or (10>=5))