
print ("Esto es el ejercicio numero dos")

a= 1/2/4.0
b=4.0**(1/2)
c=5.0**(1.0/2) + (1/2)
d=3/2 + 1
print("ESTE ES A" , a)
print("ESTE ES B" , b)
print("ESTE ES C" , c)
print("ESTE ES D" , d)