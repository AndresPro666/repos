
print("""

       SUPERMERK2""")
compra=int(input("ingrese el TOTAL DE LA COMPRA "))


if (compra<1000):
      print("el total de la compra es  ", compra)
     
if (compra>=1000):
      print("ha obtenido un descuento ")
      print("el descuento es el del 15% ")
      print("el total sin decontar es", compra)
      print("el descuento es de ", (compra * 0.15))
      print("el subtotal final es de ", compra - (compra * 0.15))

