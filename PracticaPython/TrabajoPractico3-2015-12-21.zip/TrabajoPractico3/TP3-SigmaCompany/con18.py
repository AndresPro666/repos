
print("""

       PULSASIONES""")
edad=int(input("ingrese SU EDAD "))


print("las pulsaciones cada diez segundos de usted es de  ", (220 - edad)/10)
     


