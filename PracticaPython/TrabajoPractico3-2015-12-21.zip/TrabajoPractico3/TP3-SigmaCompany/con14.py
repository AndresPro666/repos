
print("""

        Detectar si un numero es divisible""")
n=int(input("ingrese el numero  n "))
m=int(input("ingrese el numero  m "))
if ((n%m)==0) or ((n%m)==1):
      print("es divisible")  
else:  
 print(" no es divisible") 
