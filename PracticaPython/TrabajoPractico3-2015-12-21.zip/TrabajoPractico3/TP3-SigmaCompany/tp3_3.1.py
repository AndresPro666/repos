print ('Ingrese 10 numeros')

mayor = 0

for num in range (0,10,1) :
    x = int(input ('ingrese un numero '))
    if (x > mayor) :
        mayor = x

print ('El mayor de los 10 numeros es ',mayor)


