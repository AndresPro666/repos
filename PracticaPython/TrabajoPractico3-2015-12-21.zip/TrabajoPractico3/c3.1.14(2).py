costoFijo=10
costoPP=10
costoPM=15
costoPG=20
costoP=5
costoCh=10
costoCe=15
costoTot=0
opsion=input("Desea calcular el precio de la piza? (si/no)")
while opsion!='si' and opsion!='no':
   opsion=input("Desea calcular el precio de la piza? (si/no)")
while opsion=='si':
   sizePiza=int(input("""ingrese tamo�o piza
0=pequeña
1=mediana
2=grande""")
   if sizePize==1
      costoTot+=costoPP
   if (sizePiza==2):
      costoTot+=costoPM
   if (sizePiza==3):
      costoTot+=costoPG
   ingExtra=int(input("""Seleccione ingrediente extra:
0-Pepinillos
1-Champignones
2-Cebolla
3-No mas ingredientes extras""")
   while not (ingExtra in range(0,4):
      ingExtra=int(input("""Seleccione ingrediente extra:
0-Pepinillos
1-Champignones
2-Cebolla
3-No mas ingredientes extras""")
   while ingExtra in range(0,3):
      if ingExtra==0:
         costoTot+=costoP
      if ingExtra==1:
         costoTot+=costoCh
      if ingExtra==2:
         costoTot+=costoC
   costoTot=costoTot*1.5
   opsion=input("Desea calcular el precio de la piza? (si/no)")
   while opsion!='si' and opsion!='no':
      opsion=input("Desea calcular el precio de la piza? (si/no)")
               
      
