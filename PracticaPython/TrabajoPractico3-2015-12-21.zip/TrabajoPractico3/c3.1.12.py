litrosA=50
litrosB=55
litrosC=60
tipoGas=input("""WELCOME TO GAS STATION
ingrese tipo de gasolina: A/B/C/D(salir)""")
Recaudacion=0
while tipoGas!='A' and tipoGas!='B' and tipoGas!='C' and tipoGas!='D':
    tipoGas=input("""WELCOME TO GAS STATION
    ingrese tipo de gasolina: A/B/C/D(salir)""")
while tipoGas!='D':
    Litros=float(input('ingrese litros cargados: '))
    if (tipoGas=='A'):
        montoC=Litros*litrosA
    if (tipoGas=='B'):
        montoC=Litros*litrosB
    if (tipoGas=='C'):
        montoC=Litros*litrosC
    Recaudacion+=montoC
    print('Monto del cliente: ',montoC)
    tipoGas=input("""WELCOME TO GAS STATION
ingrese tipo de gasolina: A/B/C/D(salir)""")
    while tipoGas!='A' and tipoGas!='B' and tipoGas!='C' and tipoGas!='D':
        tipoGas=input("""WELCOME TO GAS STATION
ingrese tipo de gasolina: A/B/C/D(salir)""")
print('Monto recaudacion: ',Recaudacion)


        
    
