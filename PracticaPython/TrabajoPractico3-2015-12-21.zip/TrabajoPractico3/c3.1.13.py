contMe50=0
cont50b80=0
cont70b80=0
contMa80=0
for x in range(0,10):
    cal=int(input('ingrese calificacion de examen de fisica '))
    while cal<0 or cal>100:
        cal=int(input('ingrese calificacion de exanen de fisica '))
    if cal<50:
        contMe50+=1
    if cal>50 and cal<80:
        cont50b80+=1
    if cal>70 and cal<80:
        cont70b80+=1    
    if cal>80:
        contMa80+=1
print(contMe50,' sacaron menos de 50')
print(cont50b80,' sacaron entre 50 y 80')
print(cont70b80,' sacaron entre 70 y 80')
print(contMa80,' sacaron entre 80 y 100')
