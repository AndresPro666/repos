# -*- coding: utf-8 -*-
def edades(a,b):
	if (a==b):
		print 'son iguales'
	elif a>b:
		print a,'es la mayor edad. A ',b,'le faltan ',a-b,' años para igualarla'
	else:
		print b,'es la mayor edad. A ',a,'le faltan ',b-a,' años para igualarla'
edades(20,50)