def rango(l1,l2,x):
	if x in range(l1,l2+1):
		return 'En rango'
	elif x in range(0,l1):
		return 'a la izquierda'
	else:
		return 'a la derecha'
l1=int(input('Ingrese limite inferior: '))
l2=int(input('Ingrese limite superior: '))
x=int(input('Ingrese numero: '))
print(rango(l1,l2,x))

