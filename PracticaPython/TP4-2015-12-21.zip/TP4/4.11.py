def armo(n):
	sum=0
	for i in range(1,n+1):
		sum=sum+(1/i)
	return sum
num=int(input('Escriba un numero: '))
print(armo(num))