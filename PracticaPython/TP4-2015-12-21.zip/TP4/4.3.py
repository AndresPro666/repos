def impPar(x):
	if(x%2==0):
		for x in range(0,x+1,2):
			print(x)
	else:
		for x in range(1,x+1,2):
			print(x)
impPar(3)
impPar(6)