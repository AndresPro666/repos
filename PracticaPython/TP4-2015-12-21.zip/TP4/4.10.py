def sumImp(n):
	sum=0
	for i in range(1,(n*2),2):
		sum=sum+i
	return sum
num=int(input('Escriba un numero: '))
print(sumImp(num))