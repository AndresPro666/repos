def sumNatural(x):
	ac=0
	for x in range(1,x+1):
		ac=ac+x
	return ac
print(sumNatural(5))