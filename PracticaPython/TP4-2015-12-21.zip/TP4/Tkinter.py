import tkinter as tk
class Application(tk.Frame):
    def __init__(self, master=None):
        tk.Frame.__init__(self, master)
        self.pack()
        self.createWidgets()

    def createWidgets(self):
    	self.hi_there = tk.Label(self,text="Seleccione un ejercicio: ")
    	self.hi_there.pack(side="top")
    	self.hi_there = tk.Button(self)
    	self.hi_there["text"] = "Ejercicio 1 "
    	self.hi_there["command"] = self.say_hi
    	self.hi_there.pack(side="top")
    	self.hi_there = tk.Button(self)
    	self.hi_there["text"] = "Ejercicio 2 "
    	self.hi_there["command"] = self.say_hi
    	self.hi_there.pack(side="top")
    	self.hi_there = tk.Button(self)
    	self.hi_there["text"] = "Ejercicio 3 "
    	self.hi_there["command"] = self.say_hi
    	self.hi_there.pack(side="top")
    	self.hi_there = tk.Button(self)
    	self.hi_there["text"] = "Ejercicio 4 "
    	self.hi_there["command"] = self.say_hi
    	self.hi_there.pack(side="top")
    	self.hi_there = tk.Button(self)
    	self.hi_there["text"] = "Ejercicio 5 "
    	self.hi_there["command"] = self.say_hi
    	self.hi_there.pack(side="top")
    	self.hi_there = tk.Button(self)
    	self.hi_there["text"] = "Ejercicio 6 "
    	self.hi_there["command"] = self.say_hi
    	self.hi_there.pack(side="top")
    	self.hi_there = tk.Button(self)
    	self.hi_there["text"] = "Ejercicio 7 "
    	self.hi_there["command"] = self.say_hi
    	self.hi_there.pack(side="top")
    	self.hi_there = tk.Button(self)
    	self.hi_there["text"] = "Ejercicio 8 "
    	self.hi_there["command"] = self.say_hi
    	self.hi_there.pack(side="top")
    	self.hi_there["text"] = "Ejercicio 9 "
    	self.hi_there["command"] = self.say_hi
    	self.hi_there.pack(side="top")
    	self.hi_there = tk.Button(self)
    	self.hi_there["text"] = "Ejercicio 10 "
    	self.hi_there["command"] = self.say_hi
    	self.hi_there.pack(side="top")
    	self.hi_there = tk.Button(self)
    	self.hi_there["text"] = "Ejercicio 11 "
    	self.hi_there["command"] = self.say_hi
    	self.hi_there.pack(side="top")
    	self.hi_there = tk.Button(self)
    	self.hi_there["text"] = "Ejercicio 12 "
    	self.hi_there["command"] = self.say_hi
    	self.hi_there.pack(side="top")
    	self.hi_there = tk.Button(self)
    	self.hi_there["text"] = "Ejercicio 13 "
    	self.hi_there["command"] = self.say_hi
    	self.hi_there.pack(side="top")
    	self.hi_there = tk.Button(self)
    	self.hi_there["text"] = "Ejercicio 14 "
    	self.hi_there["command"] = self.say_hi
    	self.hi_there.pack(side="top")
    	self.hi_there = tk.Button(self)
    	self.hi_there["text"] = "Ejercicio 15 "
    	self.hi_there["command"] = self.say_hi
    	self.hi_there.pack(side="top")
    	self.hi_there = tk.Button(self)
    	self.hi_there["text"] = "Ejercicio 16 "
    	self.hi_there["command"] = self.say_hi
    	self.hi_there.pack(side="top")
    	self.hi_there = tk.Button(self)
    	self.hi_there["text"] = "Ejercicio 17 "
    	self.hi_there["command"] = self.say_hi
    	self.hi_there.pack(side="top")
    	self.hi_there = tk.Button(self)
    	self.hi_there["text"] = "Ejercicio 18 "
    	self.hi_there["command"] = self.say_hi
    	self.hi_there.pack(side="top")
    	self.hi_there = tk.Button(self)
    	self.hi_there["text"] = "Ejercicio 19 "
    	self.hi_there["command"] = self.say_hi
    	self.hi_there.pack(side="top")
    	self.hi_there = tk.Button(self)
    	self.hi_there["text"] = "Ejercicio 20 "
    	self.hi_there["command"] = self.say_hi
    	self.hi_there.pack(side="top")
    def say_hi(self):
        print("hi there, everyone!")

root = tk.Tk()
app = Application(master=root)
app.mainloop()
