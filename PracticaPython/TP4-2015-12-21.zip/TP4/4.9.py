def divisor(x,y):
	if (x%y==0):
		return True
	False
def sumDiv(x):
	sum=0
	for i in range(1,x):
		if divisor(x,i):
			sum=sum+i
	return sum
def perfecto(x):
	if (sumDiv(x)<x):
		return 'deficiente'
	elif(sumDiv(x)==x):
		return 'perfecto'
	else:
		return 'abundante'
num=int(input('Escriba un numero: '))
print(perfecto(num))
	