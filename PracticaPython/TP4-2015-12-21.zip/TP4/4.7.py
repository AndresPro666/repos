def mayuscula(x):
	if(x.lower()==x):
		return x.upper()
	else:
		print('Ya esta en mayuscula')
print(mayuscula('A'))

