def Mpul(x):
	pul=39.37
	return x*pul
def Mpie(x):
	a=Mpul(x)
	pie=(a/12)
	return pie
def pulPie(x):
	print (Mpul(x),'pulgadas ',Mpie(x),'pies')
num=int(input('Escriba un numero: '))
pulPie(num)

