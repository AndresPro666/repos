def sup(l):
	sup=l**2
	return sup
def per(l):
	per=4*l
	return per 
def suPer(l):
	print ('superficie ',sup(l))
	print ('perimetro ',per(l))
suPer(5)
