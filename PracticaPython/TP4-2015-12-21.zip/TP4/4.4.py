def pow(j,h):
	if(h==0):
		print(1)
	else:
		ac=j
		for x in range(2,h+1):
			ac=ac*j
		print(ac)
a=int(input('ingrese un numero: '))
b=int(input('ingrese un numero: '))
pow(a,b)

