def mida(a,b):
	if (len(a)==b):
		return True
	return False
print(mida('hola',10))