def sumDig(n):
	cociente=0
	resto=0
	suma=0
	cociente=n
	while (cociente>10):
		resto=cociente%10
		cociente=cociente//10
		suma=suma+resto
	suma=suma+cociente
	return suma
num=int(input('ingrese un numero '))
print(sumDig(num))




