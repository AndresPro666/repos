def areaLateral(R,g):
	pi=3.14
	return pi*R*g
def supCono(R,g):
	pi=3.14
	return pi*areaLateral(R,g)*(R**2)
print(supCono(3,8))