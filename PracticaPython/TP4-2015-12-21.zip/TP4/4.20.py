def billete(x,y):
	if (y==1):
		print (x ,' monedas de ',y)
	else:	
		cantB=x//y
		if (cantB==1):
			print (cantB, ' billete de ',y)
		else:		
			print (cantB, ' billetes de ',y)


def billetes(x,*args):
	num=x
	for i in args:
		if (num>=i):
			billete(num,i)
			num=num%i

def cambio(x):
	billetes(x,100,50,20,10,5,2,1)
cambio(575)

