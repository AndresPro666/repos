import TP4
natural(2)