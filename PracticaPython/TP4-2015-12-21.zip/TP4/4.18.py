# -*- coding: utf-8 -*-
def factorial(x):
	if(x==0):
		return 0
	else:
		if(x==1):
			return 1
		else:
			return x*factorial(x-1)
def divisor(x,y):
	if (x%y==0):
		return True
	False
def sumDiv(x):
	sum=0
	for i in range(1,x):
		if divisor(x,i):
			sum=sum+i
	return sum
def primo(x):
	if (sumDiv(x)==1):
		return True
	return False
def MultLT(x,y=1000):
	for i in range(x,y,x):
		print(i)
def opsion(a,*args):
	ops=raw_input(a)
	if ops in args:
		return ops
	opsion(a)

print("""\xc3 ENUNCIADO: Crear un programa en Python que solicite numeros naturales
hasta que el usuario desee terminar. Por cada número introducido se debera visualizar:
a. Si el número es primo: su factorial.
b. Y si el número no es primo: sus múltiplos menores que 1000""")
while opsion('Desea realizar el ejercicio? ','si','no')=='si':
	x=int(raw_input('ingrese un numero '))
	if primo(x):
		print(factorial(x))
	else:
		print(MultLT(x))


